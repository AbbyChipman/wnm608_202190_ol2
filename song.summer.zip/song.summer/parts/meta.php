<head>
    <meta charset="UTF-8">
    <title>Look and Fit </title>
    <link rel="stylesheet" href="css/gridsystem.css">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/storetheme.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="js/carousel.js"></script>
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
</head>


