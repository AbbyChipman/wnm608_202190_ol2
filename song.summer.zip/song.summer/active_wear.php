<?php

include_once "lib/php/function.php";
include_once "parts/templates.php";
    
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product List</title>

    <?php include "parts/meta.php"; ?>

    <script src="lib/js/functions.js"></script>
    <script src="js/templates.js"></script>
    <script src="js/product_list.js"></script>
</head>
<body>
    <?php include "parts/navbar.php"; ?>

    <div class="container">
        <h2>Activewear</h2>

        <div class="form-control">
            <form class="hotdog light" id="product-search">
                <input type="search" placeholder="Search Items">
            </form>
        </div>

        <div class='productlist grid gap'></div>

    </div>
    <ul class="table_of"><a href="#back_to_the_top">BACK TO THE TOP</a></ul>
</body>
</html>