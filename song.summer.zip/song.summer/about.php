<?php include_once "lib/php/function.php";?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About</title>

    <?php include "parts/meta.php"; ?>
</head>
<body>
    <?php include "parts/navbar.php"; ?>

    <div class="container">
        <div class="card soft">
            <h2>About Look and Fit</h2>
            <p>Page for the about section</p>
            <div class="about"></div>
        </div>
    </div>
    <ul class="table_of"><a href="#back_to_the_top">BACK TO THE TOP</a></ul>
</body>
</html>