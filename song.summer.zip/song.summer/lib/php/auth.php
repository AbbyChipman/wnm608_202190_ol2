<?php

function MYSQLIAuth() {
    return [
        "localhost", //mysql user name
        "summersong_wnm608ol2", //mysql user name
        "SamsungVentures1!", //mysql user password
        "summersong_wnm608ol2" //mysql database name
    ];
}
